'use strict';

customElements.define('compodoc-menu', class extends HTMLElement {
    constructor() {
        super();
        this.isNormalMode = this.getAttribute('mode') === 'normal';
    }

    connectedCallback() {
        this.render(this.isNormalMode);
    }

    render(isNormalMode) {
        let tp = lithtml.html(`<nav>
    <ul class="list">
        <li class="title">
            <a href="index.html" data-type="index-link">x-dam documentation</a>
        </li>
        <li class="divider"></li>
        ${ isNormalMode ? `<div id="book-search-input" role="search">
    <input type="text" placeholder="Type to search">
</div>
` : '' }
        <li class="chapter">
            <a data-type="chapter-link" href="index.html"><span class="icon ion-ios-home"></span>Getting started</a>
            <ul class="links">
                    <li class="link">
                        <a href="overview.html" data-type="chapter-link">
                            <span class="icon ion-ios-keypad"></span>Overview
                        </a>
                    </li>
                    <li class="link">
                        <a href="index.html" data-type="chapter-link">
                            <span class="icon ion-ios-paper"></span>README
                        </a>
                    </li>
                    <li class="link">
                            <a href="license.html"
                        data-type="chapter-link">
                            <span class="icon ion-ios-paper"></span>LICENSE
                        </a>
                    </li>
                    <li class="link">
                        <a href="dependencies.html"
                            data-type="chapter-link">
                            <span class="icon ion-ios-list"></span>Dependencies
                        </a>
                    </li>
            </ul>
        </li>
        <li class="chapter">
            <div class="simple menu-toggler" data-toggle="collapse"
              ${ isNormalMode ? 'data-target="#additional-pages"' : 'data-target="#xs-additional-pages"'}>
                <span class="icon ion-ios-book"></span>
                <span>Additional documentation</span>
                <span class="icon ion-ios-arrow-down"></span>
            </div>
            <ul class="links collapse"
                ${ isNormalMode ? 'id="additional-pages"' : 'id="xs-additional-pages"' }>
                    <li class="link ">
                        <a href="additional-documentation/configuration.html" data-type="entity-link" data-context-id="additional">Configuration</a>
                    </li>
                    <li class="link for-chapter2">
                        <a href="additional-documentation/configuration/profiles.html" data-type="entity-link" data-context-id="additional">Profiles</a>
                    </li>
                    <li class="link for-chapter2">
                        <a href="additional-documentation/configuration/themes.html" data-type="entity-link" data-context-id="additional">Themes</a>
                    </li>
                    <li class="link for-chapter2">
                        <a href="additional-documentation/configuration/environment.html" data-type="entity-link" data-context-id="additional">Environment</a>
                    </li>
            </ul>
        </li>
        <li class="chapter modules">
            <a data-type="chapter-link" href="modules.html">
                <div class="menu-toggler linked" data-toggle="collapse"
                    ${ isNormalMode ? 'data-target="#modules-links"' : 'data-target="#xs-modules-links"' }>
                    <span class="icon ion-ios-archive"></span>
                    <span class="link-name">Modules</span>
                    <span class="icon ion-ios-arrow-down"></span>
                </div>
            </a>
            <ul class="links collapse"
            ${ isNormalMode ? 'id="modules-links"' : 'id="xs-modules-links"' }>
                    <li class="link">
                        <a href="modules/AppModule.html" data-type="entity-link">AppModule</a>
                    </li>
                    <li class="link">
                        <a href="modules/DamModule.html" data-type="entity-link">DamModule</a>
                            <li class="chapter inner">
                                <div class="simple menu-toggler" data-toggle="collapse"
                                    ${ isNormalMode ? 'data-target="#components-links-module-DamModule-a9e5e0ab5e8741f596d593f1af9cf137"' : 'data-target="#xs-components-links-module-DamModule-a9e5e0ab5e8741f596d593f1af9cf137"' }>
                                    <span class="icon ion-md-cog"></span>
                                    <span>Components</span>
                                    <span class="icon ion-ios-arrow-down"></span>
                                </div>
                                <ul class="links collapse"
                                    ${ isNormalMode ? 'id="components-links-module-DamModule-a9e5e0ab5e8741f596d593f1af9cf137"' : 'id="xs-components-links-module-DamModule-a9e5e0ab5e8741f596d593f1af9cf137"' }>
                                        <li class="link">
                                            <a href="components/AssetsModalComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules">AssetsModalComponent</a>
                                        </li>
                                        <li class="link">
                                            <a href="components/DamComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules">DamComponent</a>
                                        </li>
                                        <li class="link">
                                            <a href="components/FacetComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules">FacetComponent</a>
                                        </li>
                                        <li class="link">
                                            <a href="components/FacetsComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules">FacetsComponent</a>
                                        </li>
                                        <li class="link">
                                            <a href="components/LoadingComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules">LoadingComponent</a>
                                        </li>
                                        <li class="link">
                                            <a href="components/TableComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules">TableComponent</a>
                                        </li>
                                        <li class="link">
                                            <a href="components/TableItemComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules">TableItemComponent</a>
                                        </li>
                                        <li class="link">
                                            <a href="components/TableSearchComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules">TableSearchComponent</a>
                                        </li>
                                </ul>
                            </li>
                            <li class="chapter inner">
                                <div class="simple menu-toggler" data-toggle="collapse"
                                    ${ isNormalMode ? 'data-target="#injectables-links-module-DamModule-a9e5e0ab5e8741f596d593f1af9cf137"' : 'data-target="#xs-injectables-links-module-DamModule-a9e5e0ab5e8741f596d593f1af9cf137"' }>
                                    <span class="icon ion-md-arrow-round-down"></span>
                                    <span>Injectables</span>
                                    <span class="icon ion-ios-arrow-down"></span>
                                </div>
                                <ul class="links collapse"
                                    ${ isNormalMode ? 'id="injectables-links-module-DamModule-a9e5e0ab5e8741f596d593f1af9cf137"' : 'id="xs-injectables-links-module-DamModule-a9e5e0ab5e8741f596d593f1af9cf137"' }>
                                        <li class="link">
                                            <a href="injectables/MainService.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules"}>MainService</a>
                                        </li>
                                </ul>
                            </li>
                    </li>
                    <li class="link">
                        <a href="modules/DynFormModule.html" data-type="entity-link">DynFormModule</a>
                            <li class="chapter inner">
                                <div class="simple menu-toggler" data-toggle="collapse"
                                    ${ isNormalMode ? 'data-target="#components-links-module-DynFormModule-0b02af06db91a1d4745e781bcb946b01"' : 'data-target="#xs-components-links-module-DynFormModule-0b02af06db91a1d4745e781bcb946b01"' }>
                                    <span class="icon ion-md-cog"></span>
                                    <span>Components</span>
                                    <span class="icon ion-ios-arrow-down"></span>
                                </div>
                                <ul class="links collapse"
                                    ${ isNormalMode ? 'id="components-links-module-DynFormModule-0b02af06db91a1d4745e781bcb946b01"' : 'id="xs-components-links-module-DynFormModule-0b02af06db91a1d4745e781bcb946b01"' }>
                                        <li class="link">
                                            <a href="components/DynFormComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules">DynFormComponent</a>
                                        </li>
                                        <li class="link">
                                            <a href="components/DynQuestionComponent.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules">DynQuestionComponent</a>
                                        </li>
                                </ul>
                            </li>
                    </li>
                    <li class="link">
                        <a href="modules/FiltersModule.html" data-type="entity-link">FiltersModule</a>
                    </li>
            </ul>
        </li>
        <li class="chapter">
            <div class="simple menu-toggler" data-toggle="collapse"
            ${ isNormalMode ? 'data-target="#classes-links"' : 'data-target="#xs-classes-links"' }>
                <span class="icon ion-ios-paper"></span>
                <span>Classes</span>
                <span class="icon ion-ios-arrow-down"></span>
            </div>
            <ul class="links collapse"
            ${ isNormalMode ? 'id="classes-links"' : 'id="xs-classes-links"' }>
                    <li class="link">
                        <a href="classes/Asset.html" data-type="entity-link">Asset</a>
                    </li>
                    <li class="link">
                        <a href="classes/ConfigMapper.html" data-type="entity-link">ConfigMapper</a>
                    </li>
                    <li class="link">
                        <a href="classes/DepDropQuestion.html" data-type="entity-link">DepDropQuestion</a>
                    </li>
                    <li class="link">
                        <a href="classes/DropdownQuestion.html" data-type="entity-link">DropdownQuestion</a>
                    </li>
                    <li class="link">
                        <a href="classes/FormMapper.html" data-type="entity-link">FormMapper</a>
                    </li>
                    <li class="link">
                        <a href="classes/Item.html" data-type="entity-link">Item</a>
                    </li>
                    <li class="link">
                        <a href="classes/QuestionBase.html" data-type="entity-link">QuestionBase</a>
                    </li>
                    <li class="link">
                        <a href="classes/RouterMapper.html" data-type="entity-link">RouterMapper</a>
                    </li>
                    <li class="link">
                        <a href="classes/TextAreaQuestion.html" data-type="entity-link">TextAreaQuestion</a>
                    </li>
                    <li class="link">
                        <a href="classes/TextboxQuestion.html" data-type="entity-link">TextboxQuestion</a>
                    </li>
            </ul>
        </li>
                <li class="chapter">
                    <div class="simple menu-toggler" data-toggle="collapse"
                        ${ isNormalMode ? 'data-target="#injectables-links"' : 'data-target="#xs-injectables-links"' }>
                        <span class="icon ion-md-arrow-round-down"></span>
                        <span>Injectables</span>
                        <span class="icon ion-ios-arrow-down"></span>
                    </div>
                    <ul class="links collapse"
                    ${ isNormalMode ? 'id="injectables-links"' : 'id="xs-injectables-links"' }>
                            <li class="link">
                                <a href="injectables/QuestionControlService.html" data-type="entity-link">QuestionControlService</a>
                            </li>
                    </ul>
                </li>
        <li class="chapter">
            <div class="simple menu-toggler" data-toggle="collapse"
            ${ isNormalMode ? 'data-target="#miscellaneous-links"' : 'data-target="#xs-miscellaneous-links"' }>
                <span class="icon ion-ios-cube"></span>
                <span>Miscellaneous</span>
                <span class="icon ion-ios-arrow-down"></span>
            </div>
            <ul class="links collapse"
            ${ isNormalMode ? 'id="miscellaneous-links"' : 'id="xs-miscellaneous-links"' }>
                    <li class="link">
                      <a href="miscellaneous/variables.html" data-type="entity-link">Variables</a>
                    </li>
            </ul>
        </li>
        <li class="chapter">
            <a data-type="chapter-link" href="coverage.html"><span class="icon ion-ios-stats"></span>Documentation coverage</a>
        </li>
        <li class="divider"></li>
        <li class="copyright">
                Documentation generated using <a href="https://compodoc.app/" target="_blank">
                            <img data-src="images/compodoc-vectorise.svg" class="img-responsive" data-type="compodoc-logo">
                </a>
        </li>
    </ul>
</nav>`);
        this.innerHTML = tp.strings;
    }
});
